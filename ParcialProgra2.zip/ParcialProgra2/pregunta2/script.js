funcion alerta(){
    alert("hora de cenar!")
}